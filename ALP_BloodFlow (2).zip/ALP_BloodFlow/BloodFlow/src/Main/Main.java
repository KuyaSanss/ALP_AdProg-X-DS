package Main;

import App.App;

public class Main {
    public static void main(String[] args) throws Exception {
        App app = new App();
    }
}
