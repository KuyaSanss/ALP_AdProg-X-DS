package User;

import App.App;
import Model.RiwayatDonor;
import Request.Request;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.LinkedList;
import java.util.Scanner;

public class UDD extends User {
    private String alamat;
    private static LinkedList<KantongDarah> daftarKantongDarah = new LinkedList<>();
    private static int counterIdDarah = 1;

    public UDD(String username, String password, String noTelp, String alamat, String nama) {
        super(username, password, noTelp, nama);
        this.alamat = alamat;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    @Override
    public void tampilkanMenuUtama(App app) {

        System.out.println("=== MENU UTAMA ===");
        System.out.println("1. Buat Cek Permintaan");
        System.out.println("2. Input Darah Masuk");
        System.out.println("0. Log Out");
        System.out.print("input: ");
        String input = app.getSc().next() + app.getSc().nextLine();
        System.out.println();
        switch (input) {
            case "0":
                app.menuAwal();
                break;
            case "1":
                checkRequest(app);
                break;
            case "2":
                inputDarahMasuk(app);
                break;
            default:
                System.out.println("Invalid Input!!");
                tampilkanMenuUtama(app);
        }
    }

    private void inputDarahMasuk(App app) {
        Scanner sc = app.getSc();

        System.out.println("=== DAFTAR PENDONOR ===");

        for (User user : app.getDataUser().getDaftarPendonor().values()) {

            Pendonor pendonor = (Pendonor) user;

            System.out.println("ID: " + pendonor.getIdPengguna()+ " | Nama: " + pendonor.getUsername());
        }

        User user;

        do {
            System.out.print("ID Pendonor: ");
            String idPendonor = sc.next() + sc.nextLine();

            user = app.getDataUser().getDaftarPendonor().get(idPendonor);

            if (user == null) {
                System.out.println("Pendonor tidak ditemukan!");
            } else {
                break;
            }
        } while (true);

        Pendonor pendonor = (Pendonor) user;

        System.out.println("Pendonor ditemukan: " + pendonor.getUsername());

        if (pendonor.getTanggalTerakhirDonor() != null
                &&
                !pendonor.getTanggalTerakhirDonor()
                        .isEmpty()) {

            try {

                LocalDate tanggalTerakhir = LocalDate.parse(
                        pendonor.getTanggalTerakhirDonor());

                LocalDate bolehDonorLagi = tanggalTerakhir.plusDays(90);

                long sisaHari = ChronoUnit.DAYS.between(
                        LocalDate.now(),
                        bolehDonorLagi);

                if (sisaHari > 0) {

                    System.out.println();
                    System.out.println(
                            "Pendonor belum layak donor.");

                    System.out.println(
                            "Silakan tunggu "
                                    + sisaHari
                                    + " hari lagi.");

                    return;
                }

            } catch (Exception e) {

                System.out.println(
                        "Format tanggal donor salah");

                return;
            }
        }

        System.out.print("ID Kantong Darah: ");
        String idDarah = String.valueOf(counterIdDarah++);

        KantongDarah darah = new KantongDarah(idDarah, pendonor.getIdPengguna(), pendonor.getGolDarah(),
                pendonor.getRhesus());

        daftarKantongDarah.add(darah);

        RiwayatDonor riwayat = new RiwayatDonor(darah.getTanggalMasuk().toString(), darah.getIdDarah(), this.getNama());

        pendonor.addRiwayatDonor(riwayat);
        pendonor.setTanggalTerakhirDonor(darah.getTanggalMasuk().toString());

        System.out.println("Kantong darah berhasil ditambahkan!");
        System.out.println("Golongan: " + darah.getJenisDarah() + " " + darah.getRhesus());

        System.out.println("Kadaluarsa: " + darah.getTanggalKadaluarsa());
    }

    public void checkRequest(App app) {
        Request request = Request.displayRequests(app);
        request.approveRequest(app);
    }
}
